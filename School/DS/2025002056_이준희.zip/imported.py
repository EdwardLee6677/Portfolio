a = 1
if __name__ == "__main__":
    print(a * 2)
else:
    print(__name__)