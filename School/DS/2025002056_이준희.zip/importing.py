from imported import a
if __name__ == "__main__":
    print(a * 3)
else:
    print(a ** 2)
