import openpyxl

t1 = open("ScienceDirect_citations_1654608099784.txt", "r")
list = f.readlines()
f.close()