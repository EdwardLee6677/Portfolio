import random

class Building(object):

    def __init__(self):
        while True:
            try:
                num_of_floors = int(input("input num_of_floors:"))
                self.num_of_floors = num_of_floors
                break
            except ValueError:
                print("Wrong Input!!!")

        while True:
            try:
                num_of_customers = int(input("input num_of_customers:"))
                self.num_of_customers = num_of_customers
                print("\n")
                break
            except ValueError:
                print("Wrong Input!!!")

        self.elevator = Elevator(self.num_of_floors)
        self.register_list=[]
        for i in range(self.num_of_customers): self.register_list.append(Customer(i+1, self.num_of_floors))

    def run(self):
        while True:
            count_finished = 0
            self.elevator.register_customer(self.register_list)
            self.elevator.cancel_customer(self.register_list)
            self.output()
            print("\n"+"->"*35+"\n")
            for i in range(self.num_of_customers):
                if self.register_list[i].finished == True:
                    count_finished += 1
            if count_finished == self.num_of_customers:
                print("\nAll Customers Arrived at Destination")
                break
            self.elevator.move()

    def output(self):
        print("\nElevator's Current Floor : %d \tElevator's direction: %s\nCustomers: "%(self.elevator.cur_floor, self.elevator.direction))
        for i in range(len(self.register_list)):
            print("\tCustomer %d \tcurrent floor : %d \tdestination floor : %d\n\t\t\tin Elevator : %s \tis Finished : %s"%(self.register_list[i].ID, self.register_list[i].cur_floor, self.register_list[i].dst_floor, self.register_list[i].in_elevator, self.register_list[i].finished))

class Elevator(object):
    def __init__(self, num_of_floors):
        self.cur_floor = 1
        self.direction = "up"
        self.num_of_floors = num_of_floors
        if self.cur_floor == self.num_of_floors:
            self.direction = "down"

    def move(self):
        if self.direction == "up":
            if self.cur_floor == self.num_of_floors:
                print("The Elevator is on the Top Floor Now")
                self.cur_floor -= 1
                print("Elevator : %d -> %d"%(self.cur_floor + 1, self.cur_floor))
                self.direction = "down"
            else:
                self.cur_floor += 1
                print("Elevator : %d -> %d"%(self.cur_floor - 1, self.cur_floor))
        else:
            if self.cur_floor == 1:
                print("The Elevator is on the Bottom Floor Now")
                self.cur_floor += 1
                print("Elevator : %d -> %d"%(self.cur_floor - 1, self.cur_floor))
                self.direction = "up"
            else:
                self.cur_floor -= 1
                print("Elevator : %d -> %d"%(self.cur_floor + 1, self.cur_floor))

    def register_customer(self, register_list):
        for i in range(len(register_list)):
            if register_list[i].finished == False and register_list[i].in_elevator == False:
                if register_list[i].cur_floor == self.cur_floor:
                    register_list[i].in_elevator = True
                    print("Customer %d -> Elevator"%register_list[i].ID)

    def cancel_customer(self, register_list):
        for i in range(len(register_list)):
            if register_list[i].finished == False and register_list[i].in_elevator == True:
                if register_list[i].dst_floor == self.cur_floor:
                    register_list[i].in_elevator = False
                    register_list[i].finished = True
                    print("Customer %d -> Destination Floor"%register_list[i].ID)

class Customer(object):
    def __init__(self, ID, num_of_floors):
        self.ID = ID
        self.cur_floor = random.randint(1, num_of_floors)
        self.in_elevator = self.finished = False
        while True:
            self.dst_floor = random.randint(1, num_of_floors)
            if self.cur_floor != self.dst_floor:
                break
            
Building().run()