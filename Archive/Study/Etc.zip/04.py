from cProfile import label
from turtle import color
from matplotlib import markers
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from regex import P

#데이터 로딩
filename = "C:/Users/Edward/Downloads/profit_population.csv"
df = pd.read_csv(filename)
print(df.head())
print(df.shape)

#데이터 준비
X = df.values[:, 0]
type(X)
print(X)
Y = df.values[:, 1]
m=len(Y)

# X = df.population
# Y = df.profit
print("X=", X[:5])
print("Y=", Y[:5])
print("m=", m)

#데이터 시각화 표시 - 산포도, scatter plot
plt.scatter(X, Y, color="red", marker="+")
plt.grid()
plt.rcParams["figure.figsize"] = (10, 6)
plt.xlabel("Population (10,000)")
plt.ylabel("Profit(10,000)")
plt.title("Population-Profit Scatter Plot")
plt.show()

# ndarray데이터를 행렬 전환
print(X)
X_1 = X.reshape(m, 1)
print(X_1[:5])
# 행렬계산을 위해 1로 구성된 열 생성 m개의 행
X_0 = np.ones((m, 1))
print(X_0[:5])

X = np.hstack((X_0, X_1))
print(X[:5])

theta = np.zeros(2)
print(theta)

Y_pred = np.dot(X, theta)
print(Y_pred)

errors = np.subtract(Y_pred, Y)
sqrt_errors = np.sqrt(errors)
J = 1/(2*m) * np.sum(sqrt_errors)
print(J)

# 비용계산 알고리즘 구축
def compute_cost(X, Y, theta, m):
    '''
    주어진 X,y, thera를 가지고 비용을 계산한다
    cost = 1/2m sum(y^-y)**2
    :param X: 속성의 입력 --> 독립변수/행렬 형태로
    :param y: 실제값의 입력 --> 종속변수
    :param theta: intercept하고 X 값의 가중치(기울기)의 입력
    :param m: 사례의 갯수
    :return: 비용
    '''
    # Y값 예측
    Y_pred = np.dot(X, theta)
    print(Y_pred)
    print(Y)    
    # 오류 계산
    errors = np.subtract(Y_pred, Y)
    #오류의 제공
    squared_errors = np.square(errors)
    # 비용계산 공식
    J = 1/(2*m) * np.sum(squared_errors)
    return J

cost = compute_cost(X, Y, theta, m)
print("Cost = ", str(cost))

# Gradient Descent 알고리즘 구축
def gradient_descent(X, Y, theta, alpha, iterations, m):
    '''
    Gradient Descent  알고리즘 구현
    :param X: 독립변수 매트릭스
    :param Y: 종속변수 ndarray
    :param theta: theta 0, 1 초기값 (0, 0)
    :param alpha: 학습률(오류를 얼마만큼 반영할 것인가?)
    :param iteratiolns: theta 변경하는 횟수(e.g. 200)
    :return: theta - 최종 변경된 theta 값 (e.g. 200번 수행 후 값)
             cost_history - 비용이 iteration하는 동안 얼마나 바뀌었나?
    '''

    #비용변화를 기억하는 함수
    cost_history = np.zeros(iterations)
    
    # iterations 지정된 횟수만큼 반복
    for i in range(iterations):
        Y_pred = np.dot(X, theta)
        print("prediction= ", Y_pred[:5])

        # 오류 계산
        errors = np.subtract(Y_pred, Y)
        print("errors= ", errors[:5])
        # X 를 transpose 한 후  dot product 실행
        sum_delta = (alpha/m)*np.dot(X.T, errors)
        #theta 값 갱신
        theta = theta - sum_delta
        # 현재의 theta에서 비용을 계산하여 cost_history에 저장
        cost_history[i] = compute_cost(X, Y, theta, m) 
    return theta, cost_history

iterations = 1500
theta, cost_history = gradient_descent(X, Y, theta, 0.01, iterations, m=m)
print(theta)

#회귀선 시각화
plt.scatter(X[:, 1], Y, color="red", marker="+", label="traning_data")
plt.plot(X[:, 1], np.dot(X, theta), color="green", label="linear regression")
plt.rcParams["figure.figsize"] = (10, 6)
plt.grid()
plt.xlabel("Population (10,000)")
plt.ylabel("Profit(10,000)")
plt.legend
plt.show()

# 비용 히스토리 시각화
plt.plot(range(1, iterations + 1), cost_history, color="blue")
plt.rcParams["figure.figsize"] = (10, 6)
plt.grid()
plt.xlabel("number of iterations")
plt.ylabel("cost(J)")
plt.title("Convergence of Gradient Descent")
plt.show()
