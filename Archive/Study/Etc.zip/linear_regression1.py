# 라이브러리 가져오기
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 데이터 로딩
filename = "./dataset/profit_population.csv"
df = pd.read_csv(filename)
print(df.head())
print(df.shape)

# 데이터 준비
X = df.values[:, 0]
type(X)
print(X)
y = df.values[:, 1]
m=len(y)

# X = df.population
# y = df.profit
print("X=", X[:5])
print("y=", y[:5])
print("m=", m)

# 데이터 시각화 표시 - 산포도, scatter plot
plt.scatter(X, y, color="red", marker="+")
plt.grid()
plt.rcParams["figure.figsize"] = (10, 6)
plt.xlabel("Population (10,000)")
plt.ylabel("Profit(10,000)")
plt.title("Population-Profit Scatter Plot")
plt.show()

#ndarray데이터를 행렬 변환
print(X)
X_1 = X.reshape(m, 1)
print(X_1[:5])
# 행렬 계산위해 1로 구성된 열 생성 m개의 행
X_0 = np.ones((m, 1))
print(X_0[:5])

X = np.hstack((X_0, X_1))
print(X[:5])

theta = np.zeros(2)
print(theta)

y_pred = np.dot(X, theta)
print(y_pred)

errors = np.subtract(y_pred, y)
squared_errors = np.square(errors)
J =  1/(2*m)*np.sum(squared_errors)
print(J)

# 비용 계산 알고리즘 구축
def compute_cost(X, y, theta, m):
    '''
    주어진 X,y, thera를 가지고 비용을 계산한다
    cost = 1/2m sum(y^-y)**2
    :param X: 속성의 입력 --> 독립변수/행렬 형태로
    :param y: 실제값의 입력 --> 종속변수
    :param theta: intercept하고 X 값의 가중치(기울기)의 입력
    :param m: 사례의 갯수
    :return: 비용
    '''
    # y값 예측
    y_pred = np.dot(X, theta)
    print(y_pred)
    print(y)
    #오류 계산
    errors = np.subtract(y_pred,y)
    print(errors)
    #오류의 제공
    squared_errors = np.square(errors)
    print(squared_errors)
    # 비용계산 공식
    J = 1/(2*m) * np.sum(squared_errors)
    return J

cost = compute_cost(X, y, theta, m)
print("Cost = ", str(cost))

# Gardient Decent 알고리즘 구축
def gradient_decent(X, y, theta, alpha, iterations, m):
    '''
    Gradient decent  알고리즘 구현
    :param X: 독립변수 메트릭스
    :param y: 종속변수 ndarray
    :param theta: theta 0, 1 초기값 (0, 0)
    :param alpha: 학습률(오류를 얼마만큼 반영할것인가?)
    :param iterations: theta 변경하는 횟수 (e.g. 200)
    :return: theta - 최종 변경된 theta 값 (e.g. 200번 수행 후 값)
             cost_history - 비용이 iteration하는 동안 얼마나 바뀌었나?
    '''
    #비용 변화를 기록하는 변수
    cost_history = np.zeros(iterations)
    # iterations 지정된 횟수만큼 반복
    for i in range(iterations):
        y_pred = np.dot(X, theta)
        print("prediction = ",y_pred[:5])
        # 오류 계산
        errors = np.subtract(y_pred, y)
        print("erors = ", errors[:5])
        # X를 transpose 한 후에 dot product를 실행한다
        sum_delta = (alpha/m)*np.dot(X.T, errors)
        # theta 값 고친다(갱신한다)
        theta = theta - sum_delta
        # 현재의 theta에서 비용을 계산하여 cost_history에 저장
        cost_history[i] = compute_cost(X, y, theta, m)
    return theta, cost_history

iterations = 1500
theta, cost_history = gradient_decent(X, y, theta, 0.01, iterations=iterations, m=m)
print(theta)

#회귀선 시각화
plt.scatter(X[:, 1], y, color="red",
            marker="+", label="training data")
plt.plot(X[:, 1], np.dot(X, theta), color="green",
         label="linear regression")
plt.rcParams["figure.figsize"]=(10,6)
plt.grid()
plt.xlabel("Population(10,000)")
plt.ylabel("Profit($10,000)")
plt.legend()
plt.show()

# 비용 히스토리 시각화
plt.plot(range(1, iterations+1), cost_history, color="blue")
plt.rcParams["figure.figsize"] = (10, 6)
plt.grid()
plt.xlabel("number of iterations")
plt.ylabel("cost(J)")
plt.title("Convergence of Gradient Descent")
plt.show()





