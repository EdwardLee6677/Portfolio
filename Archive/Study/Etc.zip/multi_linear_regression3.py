# 라이브러리 가져오기
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 데이터 로딩
filename = "C:/Users/Edward/Downloads/housing_prices.csv"
df = pd.read_csv(filename)
print(df.head())
print(df.shape)

# 데이터 준비
X = df.values[:, 0:2]
type(X)
print(X)
y = df.values[:, 2]
m=len(y)

print('Total no of training example (m) = %s \n'%(m))

for i in range(5):
    print('x = ', X[i,],',y = ', y[i])

def feature_normalize(X):
    mu = np.mean(X, axis = 0)
    sigma = np.std(X, axis = 0, ddof= 1)
    X_norm = (X-mu)/sigma
    return X_norm, mu, sigma

X_norm, mu, sigma = feature_normalize(X)
print('mu=', mu)
print('sigma=', sigma)
print('X_norm=', X[:5])
mu_testing = np.mean(X, axis = 0)
print("average", mu_testing)
sigma_testing = np.std(X, axis = 0, ddof =1)
print("standard deviation", sigma_testing)

X = np.hstack((np.ones((m, 1)), X_norm))
print(X[:5])
print(X.shape)

# 비용 계산 알고리즘 구축
def compute_cost(X, y, theta):

    # y값 예측
    y_pred = X.dot(theta)
    print(y_pred)
    print(y)
    #오류 계산
    errors = np.subtract(y_pred,y)
    print(errors)
    #오류의 제공
    squared_errors = np.square(errors)
    print(squared_errors)
    # 비용계산 공식
    J = 1/(2*m) * np.sum(squared_errors)
    return J

theta = np.zeros(3)
cost = compute_cost(X, y, theta)
print("Cost = ", str(cost))

# Gardient Decent 알고리즘 구축
def gradient_decent(X, y, theta, alpha, iterations):
    #비용 변화를 기록하는 변수
    cost_history = np.zeros(iterations)
    # iterations 지정된 횟수만큼 반복
    for i in range(iterations):
        # 예측값 계산
        y_pred = X.dot(theta)
        print("prediction = ",y_pred[:5])
        # 오류 계산
        errors = np.subtract(y_pred, y)
        print("errors = ", errors[:5])
        # X를 transpose 한 후에 dot product를 실행한다
        sum_delta = (alpha/m)*np.dot(X.T, errors)
        # theta 값 고친다(갱신한다)
        theta = theta - sum_delta
        # 현재의 theta에서 비용을 계산하여 cost_history에 저장
        cost_history[i] = compute_cost(X, y, theta)
    return theta, cost_history

theta = np.zeros(3)
iterations = 400
alpha = 0.15

theta, cost_history = gradient_decent(X, y, theta, alpha, iterations)
print(theta)

# 비용 히스토리 시각화
plt.plot(range(1, iterations+1), cost_history, color="blue")
plt.rcParams["figure.figsize"] = (10, 6)
plt.grid()
plt.xlabel("number of iterations")
plt.ylabel("cost(J)")
plt.title("Convergence of Gradient Descent")
plt.show()

# 학습률의 영향의 수렴 영향 시각화
iterations = 400
theta = np.zeros(3)
alpha = 0.005
theta_1, cost_history_1 = gradient_decent(X, y, theta, alpha, iterations)
alpha = 0.01
theta_2, cost_history_2 = gradient_decent(X, y, theta, alpha, iterations)
alpha = 0.02
theta_3, cost_history_3 = gradient_decent(X, y, theta, alpha, iterations)
alpha = 0.03
theta_4, cost_history_4 = gradient_decent(X, y, theta, alpha, iterations)
alpha = 0.15
theta_5, cost_history_5 = gradient_decent(X, y, theta, alpha, iterations)

plt.plot(range(1, iterations +1), cost_history_1, color ='purple', label = 'alpha = 0.005')
plt.plot(range(1, iterations +1), cost_history_2, color ='red', label = 'alpha = 0.01')
plt.plot(range(1, iterations +1), cost_history_3, color ='green', label = 'alpha = 0.02')
plt.plot(range(1, iterations +1), cost_history_4, color ='yellow', label = 'alpha = 0.03')
plt.plot(range(1, iterations +1), cost_history_5, color ='blue', label = 'alpha = 0.15')

plt.rcParams["figure.figsize"] = (10,6)
plt.grid()
plt.xlabel("Number of iterations")
plt.ylabel("cost (J)")
plt.title("Effect of Learning Rate On Convergence of Gradient Descent")
plt.legend()
plt.show()

iterations = 100
theta = np.zeros(3)
alpha = 1.32
theta_6, cost_history_6 = gradient_decent(X, y, theta, alpha, iterations)

plt.plot(range(1, iterations +1), cost_history_6, color ='brown')
plt.rcParams["figure.figsize"] = (10,6)
plt.grid()
plt.xlabel("Number of iterations")
plt.ylabel("cost (J)")
plt.title("Effect of Large Learning Rate On Convergence of Gradient Descent")
plt.show()

